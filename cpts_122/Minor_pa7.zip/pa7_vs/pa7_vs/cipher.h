#include<iostream> 
#include<string> 
#include <cctype>

#pragma once


using std::string; 
using namespace std; 


class cipher
{

public: 

	cipher()
	{
	}

	~cipher()
	{
	}

	//use getters/ setters 



protected: 

	string text; 
	bool flag; 
	string key; 


}; 

