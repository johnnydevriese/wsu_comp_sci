/*******************************************************************************************
* Programmer: Johnny Minor                                                                        *
* Class: CptS 121, Fall 2014; Lab Section 08                                               *
* Programming Assignment: Assignment #1 Equation Evaluator                                                     *
* Date: September 5, 2014                                                                       *
* Description: This program will take user input for numerous (seven) functions and output the answer       *
*******************************************************************************************/



#include<stdio.h>
#include<math.h> 
#define PI 3.14159265358979323846


int main(void){

	
	//total series resistance variables 
	int R1 = 0;
	int R2 = 0; 
	int R3 = 0; 
	float series_resistance = 0 ;

	//sales tax variables 

	float sales_tax_rate = 1.06; 
	float item_cost = 0; 
	float total_sales_tax = 0;

	//variables for right rectangular pyramid 

	float l = 0; 
	float w = 0; 
	float h = 0; 
	float volume_pyramid = 0;

	//total parallel resistance variables

	//int R1 = 0; 
	//int R2 = 0; 
	//int R3 = 0; 
	float parallel_resistance = 0; 
	
	//character encoding variables 

	char letter = '\0'; 
	int number = 0;
	char encoded_character2 = '\0'; 
	int letter_num = 0; 
	int encoded_character1 = '\0' ;

	//distance between two points 

	float x1 = 0;
	float x2 = 0;
	float y1 = 0;
	float y2 = 0;
	float distance = 0; 

	//general equation variables 

	float y = 0; 
	float x = 0; 
	float z = 0; 
	int a = 0; 


	//******** begin section of functions ******** 

	//series resistance 

	printf("Please enter the value of 3 resistors <all integers> connected in series:"); 
	scanf("%d %d %d", &R1, &R2, &R3);


	series_resistance = R1 + R2 + R3; 

	printf("Total series resistance: series_resistance = R1 + R2 + R3 = %f \n ", series_resistance); 
	

	//sales tax calculator 
	
	printf("How much was your item?"); 
	scanf("%f", &item_cost);

	total_sales_tax = (sales_tax_rate) * (item_cost); 

	printf("The total sale price of the item is: %f \n" , total_sales_tax );
	
	
	
	//volume of a right rectangular pyramid 


	printf("define the length, width and height of this right rectangular pyramid:");
	scanf("%f %f %f", &l, &w, &h);

	volume_pyramid = (l * w * h) / (float)3 ; 

	printf("The volume of this pyramid is: %f \n" , volume_pyramid );
	
	//total parallel resistance


	printf("Enter the values of this parallel restance (three):");
	scanf("%d %d %d", &R1, &R2, &R3); 

	parallel_resistance = (float)1 / ( ((float)1 / (R1)) +((float)1 / (R2)) + ((float)1 / R3))  ; 

	printf("This is the value of your parallel resistance: %f \n", parallel_resistance); 


	//character encoding 


	printf ("Enter number: ");
	scanf ("%d", &number); // the enter character will carry
	                       // down to the next scanf ()!

	printf ("Number: %d\n", number);

	printf ("Enter character: ");
	scanf (" %c", &letter); // space between " and %,
	                        // allows whitespace characters
	                        // to be ignored.

	letter_num = letter ;

	encoded_character1 = (letter_num - 97) + 65 - number ;  

	encoded_character2 = encoded_character1 ; 

	printf("This is the encoded character: %c \n", encoded_character2); 


	//Distance between two points

	printf("Please input two points as an order pair e.g. x1  y1 x2 y2: ");
	scanf("%f %f %f %f", &x1, &y1, &x2, &y2);

	distance = pow((x1 - x2),2) + pow((y1 - y2),2); 

	distance = sqrt(distance); 

	printf("this is the distance between the two points which you have chosen: %f \n", distance);

	//General equation
	

	printf("Please enter the values for y, z, x and a(integer) in the equation y = y / (3/17) - z + x / (a % 2) + PI:" );
	scanf("%f %f %f %d", &x, &y, &z, &a); 

	y = y / ((float)3 / (float)17) - z + x / (a % 2) + PI ;

	printf("This is the result of the function with specified numbers: %f \n", y); 



	return(0); 
}